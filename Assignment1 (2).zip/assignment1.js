alert( "What is your name?" );

var username = prompt( "Enter Name");

alert(" Welcome! " + username + " I hope life treats you well and you live it to the fullest! ")

let taco = prompt( " Do you like tacos? (y/n) ")

if (taco === "y"){
    alert(" Life is Full! ")
}

if(taco === "n"){
    alert(" You need a taco ASAP! ")
}